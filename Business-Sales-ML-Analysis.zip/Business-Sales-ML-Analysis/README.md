# Business Sales Performance Analysis and Machine Learning

**Portfolio project | Python | Pandas | Scikit-learn | Random Forest**

## Overview
Analysis of a fictional Nigerian motor spare-parts retailer using 1,200 synthetic transactions across eight Nigerian cities. Includes descriptive analytics, transaction-level gross-profit prediction, and monthly revenue forecasting.

All records are synthetic and do not represent actual company financial records.

## Business questions
- Which cities and products generate the most revenue and gross profit?
- What are total revenue, cost of goods sold, gross profit and gross margin?
- Can transaction-level gross profit be estimated from product, quantity, price, discount and location?
- Can historical monthly sales help estimate subsequent monthly revenue?

## Dataset
`data/business_sales.csv` contains transaction ID, date, city, product, category, quantity, unit selling price, unit cost, discount, revenue, cost of goods sold and gross profit. Currency is Nigerian naira (NGN).

## Methods
- Data checks, aggregation, KPI analysis and Matplotlib charts.
- Gross profit regression: RandomForestRegressor, one-hot encoding and an 80/20 random train-test split.
- Monthly sales forecast: lagged monthly revenue and rolling mean features with a chronological holdout.
- Metrics: MAE, RMSE and R².

## Results on the synthetic sample
Gross profit model: MAE 4,097.45 NGN; RMSE 8,540.47 NGN; R² 0.973.

Monthly revenue model: MAE 1,463,477.36 NGN; RMSE 1,761,692.61 NGN; R² -0.096.

These metrics apply only to this simulated dataset and are not evidence of performance on real business data.

## Repository structure
- `data/`: synthetic transaction dataset
- `notebooks/`: step-by-step analysis and modelling notebooks
- `outputs/`: KPI tables, predictions, evaluation metrics and charts
- `models/`: fitted model files
- `analysis.py`: reproducible command-line analysis
- `requirements.txt`: Python dependencies

## Run locally
```bash
git clone https://github.com/YOUR-USERNAME/business-sales-ml-analysis.git
cd business-sales-ml-analysis
python -m venv .venv
pip install -r requirements.txt
python analysis.py
jupyter notebook
```
Open the notebooks in `notebooks/`.

## Limitations and next steps
The data are simulated and only cover two years. Before real-world use, compare with simple baselines, use longer histories and time-aware validation, and monitor model drift. Possible extensions include a Streamlit dashboard, hyperparameter tuning and SHAP-based explanations.

## Author
Add your name and GitHub profile before publishing.
