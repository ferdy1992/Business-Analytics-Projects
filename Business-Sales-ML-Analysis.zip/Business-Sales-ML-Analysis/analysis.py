"""
Business Sales Performance Analysis and Machine Learning
All records are synthetic and intended for learning/demo purposes.
Run: python analysis.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parent
df = pd.read_csv(ROOT / "data" / "business_sales.csv", parse_dates=["date"])
df = df.drop_duplicates().dropna()
df["month"] = df["date"].dt.month

print("Business KPIs")
print(df[["revenue", "cost_of_goods_sold", "gross_profit"]].sum())
print("Gross margin (%):", round(df.gross_profit.sum()/df.revenue.sum()*100, 2))
print("\\nRevenue by city:\\n", df.groupby("city").revenue.sum().sort_values(ascending=False))

features = ["city","product","category","quantity","unit_selling_price","unit_cost","discount_pct","month"]
X, y = df[features], df["gross_profit"]
cat = ["city","product","category"]
num = [c for c in features if c not in cat]
prep = ColumnTransformer([("categorical", OneHotEncoder(handle_unknown="ignore"), cat),
                          ("numeric", "passthrough", num)])
model = Pipeline([("preprocess", prep),
                  ("random_forest", RandomForestRegressor(n_estimators=250, max_depth=12,
                    min_samples_leaf=2, random_state=42, n_jobs=-1))])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("\\nGross profit model")
print("MAE:", round(mean_absolute_error(y_test, pred), 2))
print("RMSE:", round(np.sqrt(mean_squared_error(y_test, pred)), 2))
print("R2:", round(r2_score(y_test, pred), 3))
joblib.dump(model, ROOT / "models" / "random_forest_gross_profit.pkl")

monthly = df.set_index("date").resample("MS")["revenue"].sum().reset_index()
monthly["month_num"] = monthly.date.dt.month
monthly["year"] = monthly.date.dt.year
for lag in [1,2,3]:
    monthly[f"lag_{lag}"] = monthly.revenue.shift(lag)
monthly["rolling_mean_3"] = monthly.revenue.shift(1).rolling(3).mean()
monthly = monthly.dropna()
fcols = ["month_num","year","lag_1","lag_2","lag_3","rolling_mean_3"]
split = int(len(monthly)*0.8)
tr, te = monthly.iloc[:split], monthly.iloc[split:]
sales_model = RandomForestRegressor(n_estimators=300, max_depth=5, min_samples_leaf=2, random_state=42)
sales_model.fit(tr[fcols], tr.revenue)
sales_pred = sales_model.predict(te[fcols])
print("\\nMonthly sales forecast")
print("MAE:", round(mean_absolute_error(te.revenue, sales_pred), 2))
print("RMSE:", round(np.sqrt(mean_squared_error(te.revenue, sales_pred)), 2))
print("R2:", round(r2_score(te.revenue, sales_pred), 3))
joblib.dump(sales_model, ROOT / "models" / "random_forest_monthly_sales.pkl")
